#pragma once

constexpr int WIN_WIDTH = 600, WIN_HEIGHT = 768;
constexpr float SCALE_FACTOR = 1.5f;
